<?php
/*Configuration Settings*/

define('DB_HOST', 'localhost'); /*Database Server*/
define('DB_NAME', 'FormCollector'); /*Database Name*/
define('DB_USER', 'root'); /*Database Username*/
define('DB_PWD',  ''); /*Database Password*/

?>