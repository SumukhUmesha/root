create database udemy;
create database sumukh;

use udemy; -- set udemy as the database to be used

show tables; -- shows the tables in udemy database

select database(); -- shows which database is in use

CREATE TABLE people (
PersonID int,
first_name varchar(100),
last_name varchar(100));

show tables;

CREATE TABLE people2(PersonID int not null auto_increment,
first_name varchar(100),
last_name varchar(100),
primary key(PersonID));

show tables;

show columns in people2;

ALTER TABLE people2
ADD COLUMN DOB DATE NULL;
show columns in people2;

ALTER TABLE people2
DROP COLUMN DOB;
show columns in people2;

CREATE TABLE actors(actorID int not null auto_increment,
first_name varchar(100),
last_name varchar(100),
primary key(actorID));
show columns in actors;

CREATE TABLE movies(movieID int not null auto_increment,
title varchar(200),
release_year DATE,
rating INT,
primary key(movieID));
show columns in movies;

-- modifying the table according to the course 
ALTER TABLE movies 
MODIFY COLUMN release_year INT,
MODIFY COLUMN rating VARCHAR(5);
show columns in movies;

INSERT INTO actors(first_name, last_name) VALUES
('Johnny','Depp'),
('Angelina','Jolie'),
('Brad','Pitt'),
('Leonadro','DiCaprio'),
('Dwayne','Johnson'),
('Kevin','Hart'),
('Margot','Robbie'),
('Penelope','Cruz'),
('Jennifer','Aniston'),
('Matthew','Perry');

SELECT * FROM actors;

INSERT INTO udemy.actors(first_name, last_name) VALUES
('Kate','Winslet'),
('Megan','Fox'),
('Tom','Hardy'),
('George','Clooney'),
('Owen','Wilson');

SELECT * FROM actors;

INSERT INTO movies(title, release_year, rating) VALUES
('Pirates of Carribean', 2001, 'PG-13'),
('Salt', 2010,'R'),
('Fight Club', 2005, 'R'),
('Reverant', 2015, 'PG-13'),
('Jumanji', 2017, 'U'),
('Get Hard', 2015, 'R'),
('Wolf of Wall Street', 2013, 'R');

SELECT * FROM movies;
SELECT last_name, substring(last_name,1,3)
FROM actors;

SELECT first_name, last_name, SUBSTRING(first_name,1,1), CONCAT(SUBSTRING(first_name,1,1), last_name) AS 'UserID' FROM actors;

CREATE TABLE bowling(PlayerID INT NOT NULL AUTO_INCREMENT,
first_name VARCHAR(100),
last_name VARCHAR(100),
Game1 INT,
Game2 INT,
Game3 INT,
Game4 INT,
PRIMARY KEY(PlayerID));

INSERT INTO bowling(first_name, last_name, Game1, Game2, Game3, Game4) VALUES
('Mike','Tyson', 120, 150, 95, 107),
('Jean','Paul', 85, 92, 101, 78),
('Sarah', 'Parker', 132, 103, 110, 69),
('Donald','Trump', 88, 75, 101, 120);

SELECT CONCAT(first_name, ', ', last_name) AS Player, CONCAT(SUBSTRING(first_name, 1, 1), SUBSTRING(last_name, 1, 1)) AS Initials,
Game1 AS G1, Game2 AS G2, Game3 AS G3, Game4 AS G4, 
(Game1 + Game2 + Game3 + Game4) AS 'Tournament Total', ((Game1 + Game2 + Game3 + Game4)/4) AS 'Tournament Average' FROM bowling;

SELECT * FROM actors
LIMIT 10;

SELECT * FROM actors 
ORDER BY 3 DESC;